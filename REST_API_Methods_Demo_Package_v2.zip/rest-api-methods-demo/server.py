from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse
import json
import shutil
import time


ROOT_DIR = Path(__file__).resolve().parent
DATA_DIR = ROOT_DIR / "data"
DATA_FILE = DATA_DIR / "products.json"
SEED_FILE = DATA_DIR / "products.seed.json"
HOST = "127.0.0.1"
PORT = 8000


def load_products():
    with DATA_FILE.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def save_products(products):
    with DATA_FILE.open("w", encoding="utf-8") as handle:
        json.dump(products, handle, indent=2)
        handle.write("\n")


def next_id(products):
    return max([item["id"] for item in products], default=0) + 1


def now_iso():
    return time.strftime("%Y-%m-%dT%H:%M:%S%z")


class RestDemoHandler(BaseHTTPRequestHandler):
    server_version = "RestMethodsDemo/1.0"

    def log_message(self, fmt, *args):
        print("%s - %s" % (self.address_string(), fmt % args))

    def _send_json(self, status, payload, headers=None):
        body = json.dumps(payload, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        if headers:
            for key, value in headers.items():
                self.send_header(key, value)
        self.end_headers()
        self.wfile.write(body)

    def _send_no_content(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def _send_html(self, file_name):
        html_path = ROOT_DIR / file_name
        body = html_path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_json_body(self):
        length = int(self.headers.get("Content-Length", "0"))
        if length == 0:
            return {}
        raw = self.rfile.read(length).decode("utf-8")
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            self._send_json(400, {"error": "Invalid JSON body", "raw": raw})
            return None

    def _parse_product_id(self, path):
        parts = path.strip("/").split("/")
        if len(parts) == 3 and parts[0] == "api" and parts[1] == "products":
            try:
                return int(parts[2])
            except ValueError:
                return None
        return None

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_HEAD(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if path in ["/", "/api/health", "/api/products"] or self._parse_product_id(path) is not None:
            status = 200
            if self._parse_product_id(path) is not None:
                product_id = self._parse_product_id(path)
                products = load_products()
                if not any(item["id"] == product_id for item in products):
                    status = 404
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8" if path.startswith("/api/") else "text/html; charset=utf-8")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
            self.end_headers()
            return

        self.send_response(404)
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if path == "/":
            self._send_html("client.html")
            return

        if path == "/api/health":
            self._send_json(200, {"status": "ok", "service": "REST API Methods Demo"})
            return

        if path == "/api/products":
            products = load_products()
            self._send_json(200, {"count": len(products), "data": products})
            return

        product_id = self._parse_product_id(path)
        if product_id is not None:
            products = load_products()
            product = next((item for item in products if item["id"] == product_id), None)
            if not product:
                self._send_json(404, {"error": "Product not found", "id": product_id})
                return
            self._send_json(200, product)
            return

        self._send_json(404, {"error": "Route not found", "path": path})

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if path == "/api/reset":
            shutil.copyfile(SEED_FILE, DATA_FILE)
            self._send_json(200, {"message": "Data reset to seed", "data": load_products()})
            return

        if path == "/api/products":
            body = self._read_json_body()
            if body is None:
                return
            required = ["name", "category", "price", "stock"]
            missing = [field for field in required if field not in body]
            if missing:
                self._send_json(400, {"error": "Missing required fields", "missing": missing})
                return
            products = load_products()
            product = {
                "id": next_id(products),
                "name": body["name"],
                "category": body["category"],
                "price": body["price"],
                "stock": body["stock"],
                "createdAt": now_iso(),
            }
            products.append(product)
            save_products(products)
            self._send_json(201, product, headers={"Location": f"/api/products/{product['id']}"})
            return

        self._send_json(404, {"error": "Route not found", "path": path})

    def do_PUT(self):
        product_id = self._parse_product_id(urlparse(self.path).path)
        if product_id is None:
            self._send_json(404, {"error": "Use PUT /api/products/{id}"})
            return

        body = self._read_json_body()
        if body is None:
            return
        required = ["name", "category", "price", "stock"]
        missing = [field for field in required if field not in body]
        if missing:
            self._send_json(400, {"error": "PUT replaces the full resource. Missing fields.", "missing": missing})
            return

        products = load_products()
        for index, product in enumerate(products):
            if product["id"] == product_id:
                replacement = {
                    "id": product_id,
                    "name": body["name"],
                    "category": body["category"],
                    "price": body["price"],
                    "stock": body["stock"],
                    "updatedAt": now_iso(),
                }
                products[index] = replacement
                save_products(products)
                self._send_json(200, replacement)
                return

        self._send_json(404, {"error": "Product not found", "id": product_id})

    def do_PATCH(self):
        product_id = self._parse_product_id(urlparse(self.path).path)
        if product_id is None:
            self._send_json(404, {"error": "Use PATCH /api/products/{id}"})
            return

        body = self._read_json_body()
        if body is None:
            return
        if "id" in body:
            self._send_json(400, {"error": "The id field cannot be patched"})
            return

        allowed = {"name", "category", "price", "stock"}
        invalid = [field for field in body if field not in allowed]
        if invalid:
            self._send_json(400, {"error": "Invalid fields", "invalid": invalid, "allowed": sorted(allowed)})
            return

        products = load_products()
        for product in products:
            if product["id"] == product_id:
                product.update(body)
                product["updatedAt"] = now_iso()
                save_products(products)
                self._send_json(200, product)
                return

        self._send_json(404, {"error": "Product not found", "id": product_id})

    def do_DELETE(self):
        product_id = self._parse_product_id(urlparse(self.path).path)
        if product_id is None:
            self._send_json(404, {"error": "Use DELETE /api/products/{id}"})
            return

        products = load_products()
        remaining = [product for product in products if product["id"] != product_id]
        if len(remaining) == len(products):
            self._send_json(404, {"error": "Product not found", "id": product_id})
            return

        save_products(remaining)
        self._send_no_content()


if __name__ == "__main__":
    DATA_DIR.mkdir(exist_ok=True)
    if not DATA_FILE.exists():
        shutil.copyfile(SEED_FILE, DATA_FILE)
    server = ThreadingHTTPServer((HOST, PORT), RestDemoHandler)
    print(f"REST API Methods Demo running at http://{HOST}:{PORT}")
    print("Press Ctrl+C to stop.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped.")
    finally:
        server.server_close()
