# Curl Cheatsheet: REST API Methods

Base URL:

```text
http://localhost:8000
```

## GET

```bash
curl -i http://localhost:8000/api/products
```

Interpretasi: membaca semua resource. Tidak mengubah state.

## POST

Windows PowerShell:

```powershell
curl.exe -i -X POST http://localhost:8000/api/products -H 'Content-Type: application/json' -d '{"name":"Smart Sensor","category":"iot","price":175000,"stock":12}'
```

macOS/Linux:

```bash
curl -i -X POST http://localhost:8000/api/products \
  -H "Content-Type: application/json" \
  -d '{"name":"Smart Sensor","category":"iot","price":175000,"stock":12}'
```

Interpretasi: membuat resource baru. Expected status: `201 Created`. Setelah itu jalankan `GET /api/products` untuk melihat item baru.

## PUT

Windows PowerShell:

```powershell
curl.exe -i -X PUT http://localhost:8000/api/products/1 -H 'Content-Type: application/json' -d '{"name":"Laptop Pro 14 Replacement","category":"computer","price":15500000,"stock":4}'
```

macOS/Linux:

```bash
curl -i -X PUT http://localhost:8000/api/products/1 \
  -H "Content-Type: application/json" \
  -d '{"name":"Laptop Pro 14 Replacement","category":"computer","price":15500000,"stock":4}'
```

Interpretasi: mengganti seluruh representation resource. Field wajib harus lengkap.

## PATCH

Windows PowerShell:

```powershell
curl.exe -i -X PATCH http://localhost:8000/api/products/1 -H 'Content-Type: application/json' -d '{"stock":2,"price":14900000}'
```

macOS/Linux:

```bash
curl -i -X PATCH http://localhost:8000/api/products/1 \
  -H "Content-Type: application/json" \
  -d '{"stock":2,"price":14900000}'
```

Interpretasi: mengubah sebagian field saja.

## DELETE

```bash
curl -i -X DELETE http://localhost:8000/api/products/1
```

Interpretasi: menghapus resource. Expected status: `204 No Content`. Buktikan dengan:

```bash
curl -i http://localhost:8000/api/products/1
```

Expected status: `404 Not Found`.

## Reset

```bash
curl -i -X POST http://localhost:8000/api/reset
```

Interpretasi: mengembalikan data demo ke kondisi awal.
