const pptxgen = require("pptxgenjs");
const path = require("path");
const fs = require("fs");

const outDir = path.join(__dirname, "pptx");
fs.mkdirSync(outDir, { recursive: true });
const outFile = path.join(outDir, "REST_API_Methods_Praktikum_Dosen.pptx");

const pptx = new pptxgen();
pptx.layout = "LAYOUT_WIDE";
pptx.author = "Codex";
pptx.subject = "Communication Protocols - REST API Methods Practicum";
pptx.title = "REST API Methods Practicum: POST, PUT, PATCH, DELETE";
pptx.company = "Communication Protocols";
pptx.lang = "id-ID";
pptx.theme = {
  headFontFace: "Aptos Display",
  bodyFontFace: "Aptos",
  lang: "id-ID",
};
pptx.defineLayout({ name: "WIDE", width: 13.333, height: 7.5 });
pptx.layout = "WIDE";
pptx.margin = 0;

const C = {
  ink: "172033",
  muted: "667085",
  line: "D0D5DD",
  bg: "F7F9FC",
  white: "FFFFFF",
  blue: "2563EB",
  green: "047857",
  orange: "B45309",
  red: "B42318",
  slate: "344054",
  cyan: "0891B2",
  purple: "7C3AED",
  amber: "F59E0B",
  dark: "101828",
};

function addBg(slide, title, subtitle) {
  slide.background = { color: C.bg };
  slide.addShape(pptx.ShapeType.rect, { x: 0, y: 0, w: 13.333, h: 0.62, fill: { color: C.dark }, line: { color: C.dark } });
  slide.addText("Communication Protocols Lab", { x: 0.45, y: 0.18, w: 5, h: 0.2, fontSize: 8.5, color: "D0D5DD", bold: true, charSpace: 0 });
  slide.addText(title, { x: 0.45, y: 0.84, w: 8.9, h: 0.45, fontSize: 25, bold: true, color: C.ink, margin: 0 });
  if (subtitle) slide.addText(subtitle, { x: 0.45, y: 1.28, w: 9.8, h: 0.3, fontSize: 10.5, color: C.muted, margin: 0, breakLine: false });
  slide.addText("REST methods demo", { x: 10.75, y: 0.86, w: 2.05, h: 0.25, fontSize: 9, color: C.muted, align: "right" });
}

function pill(slide, label, color, x, y, w = 0.82) {
  slide.addShape(pptx.ShapeType.roundRect, { x, y, w, h: 0.34, rectRadius: 0.05, fill: { color }, line: { color } });
  slide.addText(label, { x, y: y + 0.08, w, h: 0.12, fontSize: 8.5, bold: true, color: C.white, align: "center", margin: 0 });
}

function card(slide, x, y, w, h, title, body, accent = C.blue) {
  slide.addShape(pptx.ShapeType.rect, { x, y, w, h, fill: { color: C.white }, line: { color: C.line, width: 1 }, radius: 0.08 });
  slide.addShape(pptx.ShapeType.rect, { x, y, w: 0.08, h, fill: { color: accent }, line: { color: accent } });
  slide.addText(title, { x: x + 0.22, y: y + 0.2, w: w - 0.35, h: 0.28, fontSize: 13, bold: true, color: C.ink, margin: 0 });
  slide.addText(body, { x: x + 0.22, y: y + 0.55, w: w - 0.36, h: h - 0.68, fontSize: 9.4, color: C.slate, margin: 0.02, fit: "shrink", breakLine: false });
}

function codeBox(slide, code, x, y, w, h, title) {
  slide.addShape(pptx.ShapeType.rect, { x, y, w, h, fill: { color: C.dark }, line: { color: C.dark }, radius: 0.08 });
  if (title) slide.addText(title, { x: x + 0.16, y: y + 0.12, w: w - 0.32, h: 0.2, fontSize: 8, color: "A7F3D0", bold: true, margin: 0 });
  slide.addText(code, { x: x + 0.16, y: y + (title ? 0.42 : 0.16), w: w - 0.32, h: h - (title ? 0.55 : 0.28), fontFace: "Consolas", fontSize: 8.8, color: "D1FADF", margin: 0, fit: "shrink", breakLine: false });
}

function footer(slide, n) {
  slide.addText(`${n}`, { x: 12.38, y: 7.08, w: 0.45, h: 0.18, fontSize: 8, color: C.muted, align: "right", margin: 0 });
}

function titleSlide() {
  const s = pptx.addSlide();
  s.background = { color: C.dark };
  s.addShape(pptx.ShapeType.rect, { x: 0, y: 0, w: 13.333, h: 7.5, fill: { color: C.dark }, line: { color: C.dark } });
  s.addText("Communication Protocols", { x: 0.65, y: 0.55, w: 4, h: 0.25, fontSize: 10, bold: true, color: "A7F3D0", charSpace: 0 });
  s.addText("REST API Methods Practicum", { x: 0.65, y: 1.25, w: 8.6, h: 0.55, fontSize: 31, bold: true, color: C.white, margin: 0 });
  s.addText("POST, PUT, PATCH, DELETE yang benar-benar reflect di local API", { x: 0.65, y: 1.95, w: 8.2, h: 0.35, fontSize: 14, color: "D0D5DD", margin: 0 });
  const methods = [["GET", C.blue], ["POST", C.green], ["PUT", C.orange], ["PATCH", C.purple], ["DELETE", C.red]];
  methods.forEach((m, i) => pill(s, m[0], m[1], 0.68 + i * 1.13, 2.75, 0.94));
  s.addShape(pptx.ShapeType.rect, { x: 0.65, y: 3.48, w: 5.6, h: 1.75, fill: { color: "1D2939" }, line: { color: "475467" }, radius: 0.08 });
  s.addText("Goal kelas", { x: 0.9, y: 3.72, w: 1.5, h: 0.24, fontSize: 12, bold: true, color: C.white, margin: 0 });
  s.addText("Mahasiswa melihat sendiri bahwa mutation request mengubah state server, bukan cuma mendapat response sukses palsu.", { x: 0.9, y: 4.1, w: 4.85, h: 0.62, fontSize: 12.2, color: "EAECF0", fit: "shrink", margin: 0 });
  s.addText("Target: Postman/Hoppscotch + curl + local browser UI", { x: 0.9, y: 4.78, w: 4.7, h: 0.2, fontSize: 9.5, color: "A7F3D0", margin: 0 });
  s.addShape(pptx.ShapeType.rect, { x: 7.25, y: 1.08, w: 4.95, h: 5.25, fill: { color: "FFFFFF" }, line: { color: "344054" }, radius: 0.08 });
  s.addText("Live demo artifact", { x: 7.55, y: 1.42, w: 2.5, h: 0.25, fontSize: 12, color: C.ink, bold: true, margin: 0 });
  codeBox(s, "py server.py\n\nGET    /api/products\nPOST   /api/products\nPUT    /api/products/1\nPATCH  /api/products/1\nDELETE /api/products/1", 7.55, 1.9, 4.35, 2.45, "localhost:8000");
  s.addText("Evidence yang harus ditunjukkan: status code, response body, lalu GET ulang untuk membuktikan state berubah.", { x: 7.55, y: 4.68, w: 4.28, h: 0.64, fontSize: 11.5, color: C.slate, fit: "shrink", margin: 0 });
  footer(s, 1);
}

titleSlide();

let slideNo = 2;
{
  const s = pptx.addSlide();
  addBg(s, "Masalah di public fake API", "POST/PUT/PATCH/DELETE bisa terlihat sukses, tetapi perubahan tidak dipersist.");
  card(s, 0.55, 1.78, 3.75, 1.55, "Yang terjadi di JSONPlaceholder", "Mutation request diproses sebagai simulasi. Response bisa 200/201, tetapi resource tidak benar-benar berubah di server.", C.orange);
  card(s, 4.75, 1.78, 3.75, 1.55, "Yang terjadi di My JSON Server", "Dokumentasinya menyatakan GET, POST, PUT, PATCH, DELETE bisa dipakai, tetapi perubahan tidak persisted between calls.", C.red);
  card(s, 8.95, 1.78, 3.75, 1.55, "Risiko untuk praktikum", "Mahasiswa sulit melihat bedanya create, replace, partial update, dan delete kalau GET berikutnya tidak berubah.", C.purple);
  codeBox(s, "POST /posts -> 201 Created\nGET /posts -> data lama tetap sama\n\nKesimpulan praktikum:\nresponse sukses != state berubah", 1.05, 4.05, 5.2, 1.7, "Fake mutation behavior");
  s.addText("Solusi kelas: gunakan local mock API yang menyimpan state ke file JSON. Tetap sederhana, gratis, dan jalan di laptop mahasiswa.", { x: 6.75, y: 4.2, w: 5.2, h: 0.78, fontSize: 16, bold: true, color: C.ink, fit: "shrink", margin: 0 });
  s.addText("Referensi: JSONPlaceholder Guide dan My JSON Server documentation.", { x: 6.75, y: 5.2, w: 5.1, h: 0.24, fontSize: 9, color: C.muted, margin: 0 });
  footer(s, slideNo++);
}

{
  const s = pptx.addSlide();
  addBg(s, "Learning outcomes praktikum", "Setelah 90-120 menit, mahasiswa harus bisa menjalankan dan menjelaskan CRUD via REST.");
  const items = [
    ["Identify", "Membedakan method HTTP dan target resource endpoint."],
    ["Execute", "Menjalankan GET, POST, PUT, PATCH, DELETE di Postman dan curl."],
    ["Verify", "Membuktikan state berubah dengan GET ulang setelah mutation."],
    ["Explain", "Menjelaskan status code 200, 201, 204, 400, 404 secara praktis."],
    ["Troubleshoot", "Mendiagnosis JSON invalid, missing header, wrong endpoint, dan quoting issue."],
  ];
  items.forEach((it, i) => card(s, 0.75 + (i % 3) * 4.08, 1.75 + Math.floor(i / 3) * 1.75, 3.55, 1.25, it[0], it[1], [C.blue, C.green, C.orange, C.cyan, C.red][i]));
  s.addText("Evidence-based rule: no screenshot-only submission. Harus ada before/after GET atau command output yang menunjukkan perubahan state.", { x: 1.0, y: 5.7, w: 11.2, h: 0.36, fontSize: 15, bold: true, color: C.ink, align: "center", margin: 0 });
  footer(s, slideNo++);
}

{
  const s = pptx.addSlide();
  addBg(s, "REST methods map ke CRUD", "Gunakan kata kerja HTTP sebagai intent terhadap resource.");
  const rows = [
    ["Method", "CRUD intent", "Endpoint contoh", "Expected status", "State berubah?"],
    ["GET", "Read", "/api/products/1", "200 OK", "Tidak"],
    ["POST", "Create", "/api/products", "201 Created", "Ya, id baru muncul"],
    ["PUT", "Replace", "/api/products/1", "200 OK", "Ya, full object diganti"],
    ["PATCH", "Partial update", "/api/products/1", "200 OK", "Ya, field tertentu berubah"],
    ["DELETE", "Delete", "/api/products/1", "204 No Content", "Ya, GET id jadi 404"],
  ];
  s.addTable(rows, {
    x: 0.62, y: 1.72, w: 12.1, h: 3.95,
    border: { type: "solid", color: C.line, pt: 0.7 },
    fill: "FFFFFF",
    color: C.ink,
    fontFace: "Aptos",
    fontSize: 10.2,
    valign: "mid",
    fit: "shrink",
    margin: 0.07,
    autoFit: false,
    colW: [1.25, 1.75, 2.75, 1.75, 2.75],
    rowH: [0.42, 0.5, 0.5, 0.5, 0.5, 0.5],
  });
  s.addText("Teaching cue: selalu minta mahasiswa melakukan GET sebelum dan sesudah mutation.", { x: 0.88, y: 6.12, w: 11.4, h: 0.28, fontSize: 13.2, bold: true, color: C.blue, align: "center", margin: 0 });
  footer(s, slideNo++);
}

{
  const s = pptx.addSlide();
  addBg(s, "Mental model: response vs state", "Response sukses hanya membuktikan server menerima request. State harus diverifikasi dengan read-back.");
  codeBox(s, "1. GET /api/products\n   -> lihat data awal\n\n2. POST /api/products\n   -> 201 Created + Location\n\n3. GET /api/products\n   -> product baru muncul", 0.75, 1.78, 3.7, 3.2, "Create verification");
  codeBox(s, "1. PUT /api/products/1\n   -> full replace\n\n2. PATCH /api/products/1\n   -> partial update\n\n3. GET /api/products/1\n   -> field sudah berubah", 4.85, 1.78, 3.7, 3.2, "Update verification");
  codeBox(s, "1. DELETE /api/products/1\n   -> 204 No Content\n\n2. GET /api/products/1\n   -> 404 Not Found\n\n3. GET /api/products\n   -> item hilang", 8.95, 1.78, 3.7, 3.2, "Delete verification");
  s.addText("Kalimat kunci ke mahasiswa: jangan percaya mutation hanya dari response pertama; buktikan dengan read-back.", { x: 1.1, y: 5.75, w: 11.15, h: 0.4, fontSize: 16, bold: true, color: C.ink, align: "center", margin: 0 });
  footer(s, slideNo++);
}

{
  const s = pptx.addSlide();
  addBg(s, "Arsitektur demo lokal", "Single-file Python server, static browser UI, JSON file sebagai data store sederhana.");
  s.addShape(pptx.ShapeType.rect, { x: 0.8, y: 2.15, w: 2.25, h: 1.05, fill: { color: C.white }, line: { color: C.line }, radius: 0.08 });
  s.addText("Postman\nHoppscotch\ncurl\nBrowser UI", { x: 1.05, y: 2.34, w: 1.72, h: 0.48, fontSize: 12, bold: true, color: C.ink, align: "center", margin: 0 });
  s.addShape(pptx.ShapeType.line, { x: 3.15, y: 2.67, w: 1.55, h: 0, line: { color: C.blue, width: 2, beginArrowType: "none", endArrowType: "triangle" } });
  s.addShape(pptx.ShapeType.rect, { x: 4.85, y: 1.82, w: 3.0, h: 1.75, fill: { color: C.dark }, line: { color: C.dark }, radius: 0.08 });
  s.addText("server.py\nThreadingHTTPServer\nBaseHTTPRequestHandler", { x: 5.14, y: 2.23, w: 2.4, h: 0.62, fontFace: "Consolas", fontSize: 12, color: "D1FADF", align: "center", margin: 0 });
  s.addShape(pptx.ShapeType.line, { x: 7.95, y: 2.67, w: 1.55, h: 0, line: { color: C.green, width: 2, beginArrowType: "none", endArrowType: "triangle" } });
  s.addShape(pptx.ShapeType.rect, { x: 9.65, y: 2.15, w: 2.55, h: 1.05, fill: { color: C.white }, line: { color: C.line }, radius: 0.08 });
  s.addText("data/products.json\npersistent state", { x: 9.93, y: 2.42, w: 2.0, h: 0.32, fontFace: "Consolas", fontSize: 10.5, color: C.ink, align: "center", margin: 0 });
  card(s, 1.0, 4.55, 3.2, 1.1, "No external dependency", "Tidak perlu install Flask/FastAPI. Cocok untuk kelas pemula.", C.cyan);
  card(s, 5.05, 4.55, 3.2, 1.1, "State visible", "Mutation langsung tersimpan ke JSON file lokal.", C.green);
  card(s, 9.1, 4.55, 3.2, 1.1, "Easy reset", "`POST /api/reset` mengembalikan seed data.", C.orange);
  footer(s, slideNo++);
}

{
  const s = pptx.addSlide();
  addBg(s, "Setup demo di kelas", "Bisa dijalankan di Windows, macOS, atau Linux tanpa account dan tanpa kartu kredit.");
  codeBox(s, "cd rest-api-methods-demo\npy server.py\n\n# buka browser\nhttp://localhost:8000", 0.72, 1.82, 5.55, 2.05, "Windows");
  codeBox(s, "cd rest-api-methods-demo\npython3 server.py\n\n# buka browser\nhttp://localhost:8000", 7.03, 1.82, 5.55, 2.05, "macOS/Linux");
  card(s, 0.9, 4.65, 3.5, 1.15, "Port", "Default port 8000. Kalau konflik, ubah konstanta PORT di `server.py`.", C.blue);
  card(s, 4.9, 4.65, 3.5, 1.15, "Postman", "Import collection dari folder `postman/` lalu set variable `base_url`.", C.green);
  card(s, 8.9, 4.65, 3.5, 1.15, "Evidence", "Ambil screenshot before/after dan simpan curl command.", C.orange);
  footer(s, slideNo++);
}

{
  const s = pptx.addSlide();
  addBg(s, "Demo 1: POST create resource", "POST membuat resource baru di collection.");
  codeBox(s, "curl.exe -i -X POST http://localhost:8000/api/products \\\n  -H 'Content-Type: application/json' \\\n  -d '{\"name\":\"Smart Sensor\",\"category\":\"iot\",\"price\":175000,\"stock\":12}'", 0.65, 1.72, 6.2, 1.55, "Windows PowerShell");
  codeBox(s, "HTTP/1.0 201 Created\nLocation: /api/products/4\n\n{\n  \"id\": 4,\n  \"name\": \"Smart Sensor\",\n  \"category\": \"iot\"\n}", 7.25, 1.72, 5.45, 2.15, "Expected response");
  s.addText("Verification step", { x: 0.75, y: 4.48, w: 2.2, h: 0.28, fontSize: 14, bold: true, color: C.ink, margin: 0 });
  codeBox(s, "curl -i http://localhost:8000/api/products/4\n\nExpected: 200 OK, object dengan id 4 muncul.", 0.75, 4.9, 5.5, 1.2, null);
  card(s, 7.25, 4.74, 4.95, 1.05, "Teaching point", "POST biasanya dipakai untuk create. Server menentukan id baru dan bisa mengembalikan `Location` header.", C.green);
  footer(s, slideNo++);
}

{
  const s = pptx.addSlide();
  addBg(s, "Demo 2: PUT replace resource", "PUT mengganti representation resource secara utuh.");
  codeBox(s, "curl.exe -i -X PUT http://localhost:8000/api/products/1 \\\n  -H 'Content-Type: application/json' \\\n  -d '{\"name\":\"Laptop Pro 14 Replacement\",\"category\":\"computer\",\"price\":15500000,\"stock\":4}'", 0.65, 1.72, 6.4, 1.68, "Windows PowerShell");
  codeBox(s, "HTTP/1.0 200 OK\n\n{\n  \"id\": 1,\n  \"name\": \"Laptop Pro 14 Replacement\",\n  \"category\": \"computer\",\n  \"price\": 15500000,\n  \"stock\": 4\n}", 7.35, 1.72, 5.25, 2.35, "Expected response");
  card(s, 0.8, 4.72, 5.45, 1.1, "Teaching point", "PUT bukan sekadar update satu field. Dalam demo ini PUT diwajibkan mengirim field lengkap karena konsepnya full replace.", C.orange);
  card(s, 7.35, 4.72, 4.95, 1.1, "Common mistake", "Mahasiswa mengirim hanya `stock`, lalu server menolak dengan 400 karena missing required fields.", C.red);
  footer(s, slideNo++);
}

{
  const s = pptx.addSlide();
  addBg(s, "Demo 3: PATCH partial update", "PATCH mengubah field tertentu tanpa mengganti object seluruhnya.");
  codeBox(s, "curl.exe -i -X PATCH http://localhost:8000/api/products/1 \\\n  -H 'Content-Type: application/json' \\\n  -d '{\"stock\":2,\"price\":14900000}'", 0.65, 1.72, 6.4, 1.45, "Windows PowerShell");
  codeBox(s, "HTTP/1.0 200 OK\n\n{\n  \"id\": 1,\n  \"name\": \"Laptop Pro 14 Replacement\",\n  \"category\": \"computer\",\n  \"price\": 14900000,\n  \"stock\": 2\n}", 7.35, 1.72, 5.25, 2.35, "Expected response");
  card(s, 0.8, 4.72, 5.45, 1.1, "Teaching point", "`name` dan `category` tetap sama. Yang berubah hanya `price` dan `stock`.", C.purple);
  card(s, 7.35, 4.72, 4.95, 1.1, "Troubleshooting", "Kalau response 400, cek apakah field yang dikirim termasuk allowed fields dan JSON valid.", C.blue);
  footer(s, slideNo++);
}

{
  const s = pptx.addSlide();
  addBg(s, "Demo 4: DELETE resource", "DELETE menghapus resource. Bukti utamanya adalah read-back menjadi 404.");
  codeBox(s, "curl -i -X DELETE http://localhost:8000/api/products/1", 0.65, 1.72, 5.4, 0.9, "Delete command");
  codeBox(s, "HTTP/1.0 204 No Content\n\n(no response body)", 7.15, 1.72, 5.0, 0.9, "Expected response");
  codeBox(s, "curl -i http://localhost:8000/api/products/1", 0.65, 3.32, 5.4, 0.9, "Verification command");
  codeBox(s, "HTTP/1.0 404 Not Found\n\n{\n  \"error\": \"Product not found\",\n  \"id\": 1\n}", 7.15, 3.32, 5.0, 1.45, "Expected read-back");
  s.addText("Teaching cue: response `204` memang tidak punya body. Jangan dipaksa parse JSON.", { x: 1.05, y: 5.75, w: 11.15, h: 0.3, fontSize: 15, bold: true, color: C.red, align: "center", margin: 0 });
  footer(s, slideNo++);
}

{
  const s = pptx.addSlide();
  addBg(s, "Postman/Hoppscotch guided flow", "Alur lab yang bisa diikuti mahasiswa tanpa terlalu banyak setup.");
  const steps = [
    ["1", "Import collection", "Import `REST_API_Methods_Local_Demo.postman_collection.json`."],
    ["2", "Health check", "Run `GET /api/health` untuk memastikan server hidup."],
    ["3", "GET before", "Run `GET /api/products` dan screenshot kondisi awal."],
    ["4", "Mutation", "Run POST, PUT, PATCH, DELETE secara berurutan."],
    ["5", "GET after", "Buktikan perubahan dengan GET ulang."],
  ];
  steps.forEach((st, i) => {
    const x = 0.7 + (i % 3) * 4.1;
    const y = 1.75 + Math.floor(i / 3) * 1.8;
    s.addShape(pptx.ShapeType.ellipse, { x, y, w: 0.52, h: 0.52, fill: { color: [C.blue, C.green, C.orange, C.purple, C.red][i] }, line: { color: [C.blue, C.green, C.orange, C.purple, C.red][i] } });
    s.addText(st[0], { x, y: y + 0.14, w: 0.52, h: 0.12, fontSize: 11, bold: true, color: C.white, align: "center", margin: 0 });
    card(s, x + 0.68, y - 0.05, 3.0, 1.12, st[1], st[2], [C.blue, C.green, C.orange, C.purple, C.red][i]);
  });
  s.addText("Minimal evidence: screenshot request, status code, response body, dan GET after.", { x: 1.1, y: 5.78, w: 11.0, h: 0.28, fontSize: 14.5, bold: true, color: C.ink, align: "center", margin: 0 });
  footer(s, slideNo++);
}

{
  const s = pptx.addSlide();
  addBg(s, "Common mistakes yang sering muncul", "Masalah teknis kecil bisa jadi bahan troubleshooting yang bagus.");
  const items = [
    ["PowerShell curl alias", "Pakai `curl.exe`, bukan alias `curl` PowerShell."],
    ["Invalid JSON", "Gunakan single quote di PowerShell atau Postman raw JSON."],
    ["Missing header", "Tambahkan `Content-Type: application/json`."],
    ["PUT vs PATCH", "PUT full replace, PATCH partial update."],
    ["DELETE no body", "204 No Content itu normal, jangan parse JSON."],
    ["Lupa read-back", "Selalu GET ulang setelah mutation."],
  ];
  items.forEach((it, i) => card(s, 0.65 + (i % 3) * 4.15, 1.65 + Math.floor(i / 3) * 1.75, 3.65, 1.25, it[0], it[1], [C.red, C.orange, C.blue, C.purple, C.green, C.cyan][i]));
  footer(s, slideNo++);
}

{
  const s = pptx.addSlide();
  addBg(s, "Mini assignment Edlink", "Output kecil, tapi evidence-nya harus kuat.");
  s.addTable([
    ["Deliverable", "Isi minimal"],
    ["Screenshot before", "GET /api/products sebelum mutation"],
    ["POST evidence", "201 Created + Location + GET id baru"],
    ["PUT evidence", "200 OK + object terganti penuh"],
    ["PATCH evidence", "200 OK + field tertentu berubah"],
    ["DELETE evidence", "204 No Content + GET id menjadi 404"],
    ["Reflection", "3 common mistakes dan cara troubleshooting"],
  ], {
    x: 0.85, y: 1.72, w: 7.1, h: 4.2,
    border: { type: "solid", color: C.line, pt: 0.7 },
    fill: C.white,
    color: C.ink,
    fontSize: 10.5,
    margin: 0.07,
    fit: "shrink",
    colW: [2.15, 4.4],
  });
  card(s, 8.45, 1.9, 3.8, 1.1, "Format", "PDF 2-3 halaman atau Markdown di GitHub.", C.blue);
  card(s, 8.45, 3.32, 3.8, 1.1, "Tools", "Postman/Hoppscotch dan curl minimal satu command.", C.green);
  card(s, 8.45, 4.75, 3.8, 1.1, "Nilai plus", "Sertakan Postman test script atau Wireshark capture HTTP lokal.", C.orange);
  footer(s, slideNo++);
}

{
  const s = pptx.addSlide();
  addBg(s, "Rubrik praktikum singkat", "Beri nilai ke pemahaman method, bukan hanya screenshot cantik.");
  s.addTable([
    ["Komponen", "Bobot", "Indikator"],
    ["Execution", "35%", "Semua method berjalan dan urutan demo benar."],
    ["Evidence", "30%", "Ada before/after GET, status code, body, dan command."],
    ["Analysis", "20%", "Mahasiswa menjelaskan POST vs PUT vs PATCH vs DELETE."],
    ["Troubleshooting", "10%", "Mencatat error dan solusi."],
    ["Professionalism", "5%", "File rapi, nama jelas, submit tepat format."],
  ], {
    x: 0.9, y: 1.85, w: 11.55, h: 3.65,
    border: { type: "solid", color: C.line, pt: 0.7 },
    fill: C.white,
    color: C.ink,
    fontSize: 11,
    margin: 0.07,
    fit: "shrink",
    colW: [2.6, 1.25, 7.0],
  });
  s.addText("Pertanyaan pemantik: kalau POST return 201 tetapi GET tidak berubah, apakah API-nya salah atau memang mock server-nya tidak persist?", { x: 1.2, y: 6.08, w: 10.8, h: 0.32, fontSize: 13.5, bold: true, color: C.purple, align: "center", margin: 0 });
  footer(s, slideNo++);
}

{
  const s = pptx.addSlide();
  addBg(s, "Close: script live demo 10 menit", "Urutan ngomong dosen saat unjuk praktikum.");
  const script = [
    ["1 menit", "Tunjukkan public fake API: mutation sukses tapi state tidak persist."],
    ["1 menit", "Run `py server.py`, buka `http://localhost:8000`."],
    ["2 menit", "POST product baru, lalu GET id baru."],
    ["2 menit", "PUT product 1, lalu GET product 1."],
    ["2 menit", "PATCH product 1, lalu GET product 1."],
    ["2 menit", "DELETE product 1, lalu GET product 1 sampai 404."],
  ];
  s.addTable([["Durasi", "Action"], ...script], {
    x: 0.85, y: 1.75, w: 7.0, h: 4.35,
    border: { type: "solid", color: C.line, pt: 0.7 },
    fill: C.white,
    color: C.ink,
    fontSize: 10.5,
    margin: 0.07,
    fit: "shrink",
    colW: [1.4, 5.1],
  });
  codeBox(s, "Final proof:\n\nDELETE -> 204\nGET same id -> 404\n\nItu bukti state server berubah.", 8.35, 2.15, 3.6, 2.15, "Key takeaway");
  s.addText("Gunakan reset kalau demo perlu diulang: POST /api/reset", { x: 8.35, y: 4.72, w: 3.7, h: 0.3, fontSize: 12.5, bold: true, color: C.green, align: "center", margin: 0 });
  footer(s, slideNo++);
}

{
  const s = pptx.addSlide();
  addBg(s, "References", "Sumber resmi untuk menjelaskan behavior public fake API dan HTTP methods.");
  const refs = [
    "JSONPlaceholder. (n.d.). Guide. https://jsonplaceholder.typicode.com/guide",
    "My JSON Server. (n.d.). Fake online REST server. https://my-json-server.typicode.com/",
    "Fielding, R., Nottingham, M., & Reschke, J. (2022). RFC 9110: HTTP Semantics. https://www.rfc-editor.org/rfc/rfc9110",
    "Postman. (n.d.). Send API requests and write tests. https://learning.postman.com/",
    "curl. (n.d.). curl command line tool. https://curl.se/"
  ];
  refs.forEach((r, i) => s.addText(r, { x: 0.85, y: 1.65 + i * 0.66, w: 11.65, h: 0.32, fontSize: 10.5, color: C.ink, margin: 0, fit: "shrink" }));
  card(s, 0.85, 5.55, 11.55, 0.72, "Catatan dosen", "Untuk demo state-changing methods, public fake API cukup untuk response syntax, tetapi local mock API lebih tepat untuk membuktikan perubahan state.", C.blue);
  footer(s, slideNo++);
}

pptx.writeFile({ fileName: outFile });
console.log(outFile);

