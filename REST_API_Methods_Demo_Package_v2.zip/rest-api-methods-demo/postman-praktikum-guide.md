# Panduan Praktikum Postman: POST, PUT, PATCH, DELETE

Tujuan guide ini: dosen menjalankan semua method REST selain `GET` menggunakan **Postman**, lalu membuktikan perubahan state dengan request `GET` ulang.

## 1. Jalankan Local API Server

Windows:

```powershell
cd "C:\Users\Yenny-Haikal\OneDrive\Documents\New project\rest-api-methods-demo"
py server.py
```

Jika berhasil, terminal menampilkan:

```text
REST API Methods Demo running at http://127.0.0.1:8000
```

Jangan tutup terminal selama praktikum.

## 2. Import Postman Collection

Di Postman:

1. Klik **Import**.
2. Pilih file:

```text
postman/REST_API_Methods_Local_Demo.postman_collection.json
```

3. Setelah import, collection akan muncul dengan nama:

```text
REST API Methods Local Demo
```

Collection sudah memiliki variable:

```text
base_url = http://localhost:8000
```

## 3. Urutan Demo yang Disarankan

### A. Health Check

Request:

```text
GET {{base_url}}/api/health
```

Expected:

```json
{
  "status": "ok",
  "service": "REST API Methods Demo"
}
```

Teaching point: Postman berhasil connect ke server lokal.

### B. GET Before

Request:

```text
GET {{base_url}}/api/products
```

Expected:

```json
{
  "count": 3,
  "data": [...]
}
```

Teaching point: ini kondisi awal sebelum mutation.

## 4. POST: Create Product

Request:

```text
POST {{base_url}}/api/products
```

Headers:

```text
Content-Type: application/json
```

Body tab:

1. Pilih **Body**.
2. Pilih **raw**.
3. Pilih format **JSON**.
4. Isi:

```json
{
  "name": "Smart Sensor",
  "category": "iot",
  "price": 175000,
  "stock": 12
}
```

Expected status:

```text
201 Created
```

Expected response:

```json
{
  "id": 4,
  "name": "Smart Sensor",
  "category": "iot",
  "price": 175000,
  "stock": 12,
  "createdAt": "..."
}
```

Verification:

```text
GET {{base_url}}/api/products/4
```

Teaching point: `POST` membuat resource baru. Jangan hanya percaya `201`; buktikan dengan `GET` ulang.

## 5. PUT: Replace Full Product

Request:

```text
PUT {{base_url}}/api/products/1
```

Body:

```json
{
  "name": "Laptop Pro 14 Replacement",
  "category": "computer",
  "price": 15500000,
  "stock": 4
}
```

Expected status:

```text
200 OK
```

Verification:

```text
GET {{base_url}}/api/products/1
```

Expected: object id `1` berubah menjadi versi replacement.

Teaching point: `PUT` mengganti full representation. Kalau field wajib kurang, server akan return `400 Bad Request`.

## 6. PATCH: Partial Update

Request:

```text
PATCH {{base_url}}/api/products/1
```

Body:

```json
{
  "stock": 2,
  "price": 14900000
}
```

Expected status:

```text
200 OK
```

Verification:

```text
GET {{base_url}}/api/products/1
```

Expected: hanya `stock` dan `price` berubah. Field `name` dan `category` tetap.

Teaching point: `PATCH` cocok untuk partial update.

## 7. DELETE: Delete Product

Request:

```text
DELETE {{base_url}}/api/products/1
```

Expected status:

```text
204 No Content
```

Expected body:

```text
Kosong
```

Verification:

```text
GET {{base_url}}/api/products/1
```

Expected:

```text
404 Not Found
```

Teaching point: `204 No Content` itu normal untuk delete. Bukti resource terhapus adalah `GET` setelah delete menjadi `404`.

## 8. Reset Data Jika Mau Demo Ulang

Request:

```text
POST {{base_url}}/api/reset
```

Expected:

```text
200 OK
```

Data kembali ke seed awal.

## 9. Evidence yang Mahasiswa Harus Ambil

| Evidence | Wajib |
|---|---|
| Screenshot `GET /api/products` sebelum mutation | Ya |
| Screenshot `POST` response `201 Created` | Ya |
| Screenshot `GET /api/products/4` setelah POST | Ya |
| Screenshot `PUT` response dan `GET` setelahnya | Ya |
| Screenshot `PATCH` response dan `GET` setelahnya | Ya |
| Screenshot `DELETE` response `204 No Content` | Ya |
| Screenshot `GET` setelah DELETE menjadi `404` | Ya |

## 10. Common Mistakes di Postman

| Masalah | Penyebab | Solusi |
|---|---|---|
| `400 Invalid JSON body` | Body bukan JSON valid | Body -> raw -> JSON, cek koma dan tanda kutip |
| `400 Missing required fields` | PUT tidak mengirim field lengkap | Kirim `name`, `category`, `price`, dan `stock` |
| `404 Product not found` | ID sudah dihapus atau belum ada | Jalankan `POST /api/reset` |
| `Could not send request` | Server belum jalan | Jalankan `py server.py` |
| `localhost refused to connect` | Port/server mati | Cek terminal server, pastikan port 8000 |

## 11. Script Dosen Saat Menjelaskan

Kalimat ringkas:

> Public fake API sering menerima POST/PUT/PATCH/DELETE, tetapi mutation-nya tidak persisted. Hari ini kita pakai Postman sebagai API client dan local API sebagai backend supaya perubahan state benar-benar bisa dilihat.

Kalimat penutup:

> Dalam REST API testing, response sukses belum cukup. Kita harus verify dengan read-back request, biasanya GET ulang ke resource yang sama.

